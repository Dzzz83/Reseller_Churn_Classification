SET NOCOUNT ON;
SELECT c.StoreID, h.SalesOrderID,
       CONVERT(varchar(23), h.OrderDate, 121) AS OrderDate, h.SubTotal
FROM Sales.SalesOrderHeader h
JOIN Sales.Customer c ON c.CustomerID = h.CustomerID
WHERE c.StoreID IS NOT NULL AND h.OrderDate < '20131001'
ORDER BY h.SalesOrderID;
