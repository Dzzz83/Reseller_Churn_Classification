SET NOCOUNT ON;
SELECT d.SalesOrderID, d.SalesOrderDetailID, d.ProductID,
       d.OrderQty, d.UnitPrice, d.UnitPriceDiscount, d.LineTotal
FROM Sales.SalesOrderDetail d
JOIN Sales.SalesOrderHeader h ON h.SalesOrderID = d.SalesOrderID
JOIN Sales.Customer c ON c.CustomerID = h.CustomerID
WHERE c.StoreID IS NOT NULL AND h.OrderDate < '20131001'
ORDER BY d.SalesOrderID, d.SalesOrderDetailID;
