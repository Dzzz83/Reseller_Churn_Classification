import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {PresentationFile,FileBlob} from '@oai/artifact-tool';
const root='C:/Users/dzzz83/Documents/code/Reseller_Churn_Classification';
const build=path.join(root,'results/presentation-build');
const skill='C:/Users/dzzz83/.codex/plugins/cache/openai-primary-runtime/presentations/26.1013.11914/skills/presentations';
process.on('uncaughtException',e=>{console.error(e.stack);process.exit(1)});
const {finalizePresentation,applyPresentationChartFont}=await import(pathToFileURL(path.join(skill,'container_tools/artifact_tool_utils.mjs')));
const p=await PresentationFile.importPptx(await FileBlob.load(path.join(root,'results/presentation-output/reseller-churn-with-verified-row.pptx')));
async function render(slide,name){const blob=await p.export({slide,format:'png',scale:1});const bytes=Buffer.from(await blob.arrayBuffer());await fs.writeFile(path.join(build,name),bytes);return crypto.createHash('sha256').update(bytes).digest('hex');}
const before=[];for(let i=0;i<8;i++)before.push(await render(p.slides.items[i],`recall-before-${i+1}.png`));
const C={navy:'#142D42',teal:'#087F8C',paper:'#F6F7F5',muted:'#536674',line:'#D3DEDF',amber:'#B87513'};
const s=p.slides.add();s.background.fill=C.paper;
function text(v,x,y,w,h,size=28,color=C.navy,bold=false,align='left'){
 const a=s.shapes.add({geometry:'textbox',name:v.slice(0,60),position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});
 a.text=v;a.text.style={typeface:'Arial',fontSize:size,color,bold,insets:0,verticalAlignment:'middle',alignment:align};return a;
}
text('Why recall comes first',72,52,1456,74,48,C.navy,true);
text('Higher recall reduces missed opportunities for retention',75,142,1450,48,33,C.teal,true);
text('Results from the cited study',75,216,1450,38,26,C.muted);
function chart(title,left,values,max,step){
 const c=s.charts.add('bar',{
  position:{left,top:275,width:690,height:285},
  title,titleTextStyle:{fontSize:32,bold:true,fill:C.navy},
  categories:['XGBoost','Random Forest'],
  series:[{name:'Customers',values,fill:C.teal,points:[{idx:0,fill:C.teal},{idx:1,fill:C.navy}]}],
  hasLegend:false,
  barOptions:{direction:'bar',grouping:'clustered',gapWidth:100},
  chartFill:C.paper,plotAreaFill:C.paper,
  xAxis:{visible:true,min:0,max,majorUnit:step,numberFormatCode:'0',textStyle:{fontSize:23,fill:C.muted},majorGridlines:{fill:C.line,width:1}},
  yAxis:{visible:true,min:0,max,majorUnit:step,textStyle:{fontSize:26,fill:C.navy},majorGridlines:null},
  dataLabels:{showValue:true,position:'outEnd',numberFormatCode:'0',textStyle:{fontSize:28,bold:true,fill:C.navy}},
 });
 applyPresentationChartFont(c,{fontFamily:'Arial',availableFonts:['Arial']});return c;
}
chart('Missed churners',75,[623,650],750,250);
chart('False alerts',835,[222,182],300,100);
text('27 fewer missed churners, with 40 additional false alerts',75,591,1450,61,40,C.navy,true);
text('Prioritize recall while monitoring precision and outreach workload.',75,682,1450,48,31,C.teal,true);
text('Acceptable alert costs still require business assessment.',75,748,1450,38,26,C.muted);
text('Kumar & Kumar (2026), Table 5 and Discussion, pp. 366–367',75,808,1380,32,23,C.muted);
text('09',1475,844,55,30,22,C.muted,false,'right');
const paper='C:/Users/dzzz83/Downloads/Predicting_Customer_Churn_in_E-Commerce_Using_Mach.pdf';
const paperHash=crypto.createHash('sha256').update(await fs.readFile(paper)).digest('hex');
s.speakerNotes.text='Source: Priya Sakthi Kumar and Vinoth Kumar P (2026). Predicting Customer Churn in E-Commerce Using Machine Learning: A Comprehensive Approach. International Journal of Informatics and Information Systems, 9(2), 357–370. DOI: https://doi.org/10.47738/ijiis.v9i2.300 . User-supplied PDF: '+paper+'. SHA-256: '+paperHash+'. Evidence inspected on PDF pages 10–11, printed pages 366–367, particularly section 4.2, Table 5 in section 4.3, and section 5 Discussion.\n\nTable 5 reports Random Forest churn recall 0.77, churn precision 0.92, F1 0.84, false negatives 650, false positives 182. XGBoost reports recall 0.78, precision 0.91, F1 0.84, false negatives 623, false positives 222. Native charts reproduce the count data, not the reseller project results. The difference is 650−623=27 fewer missed churners, with 222−182=40 additional false alerts. The two count charts have separate zero-based axes and different maxima, labeled numerically. This compares two fitted models in the paper, not two cutoffs of our fixed ensemble.\n\nThe authors argue that reducing missed churners is often more important for retention-focused applications, because unflagged churners represent missed opportunities for timely retention intervention. They prefer XGBoost despite its slightly lower reported precision. This is their business interpretation; the paper does not measure causal retention uplift, intervention profitability, our reseller-specific false-negative/false-positive costs, or an optimal cost ratio. It supports recall as the primary detection metric while retaining precision and F1 as checks. It does not establish that our original cutoff 0.06 is optimal, justify our test precision of 28.48%, or waive the intended 30% development precision floor. The existing final test results remain unchanged on slide 8. The acceptable trade-off still depends on intervention cost, retention effectiveness, reseller value, and outreach capacity.';
for(let i=0;i<9;i++){
 const hash=await render(p.slides.items[i],`recall-slide-${i+1}.png`);
 if(i<8&&hash!==before[i])throw Error(`Unrelated slide ${i+1} changed visually`);
}
console.log('Existing eight slide renders unchanged');
const candidate=path.join(build,'recall-candidate.pptx');
await(await PresentationFile.exportPptx(p)).save(candidate);
const r=await finalizePresentation({workspaceDir:root,candidatePath:candidate,finalPath:path.join(root,'results/presentation-output/reseller-churn-final-nine-slides.pptx'),pythonExecutable:'C:/Users/dzzz83/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe',integrityValidatorPath:path.join(skill,'container_tools/inspect_presentation_package_integrity.py'),layoutValidatorPath:path.join(skill,'container_tools/inspect_presentation_layout_geometry.py'),layoutArgs:['--expected-slide-size-emu','15240000,8572500','--validate-heading-fit','--require-native-table-slide','4','--require-native-table-slide','6','--require-native-table-slide','7','--require-native-table-slide','8'],explicitTotalSlideCount:9,requiredNativeTableOwnerSlides:[4,6,7,8],requiredNativeChartOwnerSlides:[8,9],nativeChartTargetApplication:'powerpoint',fontPolicy:{basis:'design',families:['Arial']},verifyArtifactToolImport:true,receiptPath:path.join(build,'recall-final-validation.json')});
console.log(JSON.stringify({final:r.finalPath,slideCount:r.packageIntegrity.slide_count,findings:r.presentationLayout.finding_count,warnings:r.presentationLayout.warning_count}));

