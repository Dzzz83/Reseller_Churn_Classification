import csv
import hashlib
import io
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parents[2]
dest = Path(__file__).resolve().parent / 'source-data'
dest.mkdir(exist_ok=True)
branch = 'pipeline_preparation'
commit = subprocess.check_output(['git', 'rev-parse', branch], cwd=root, text=True).strip()
report = {'branch': branch, 'commit': commit, 'files': {}}
for name in ['ml_labeled_snapshots.csv', 'ml_test_features.csv']:
    git_path = f'datasets/processed/{name}'
    data = subprocess.check_output(['git', 'show', f'{commit}:{git_path}'], cwd=root)
    (dest / name).write_bytes(data)
    rows = list(csv.DictReader(io.StringIO(data.decode('utf-8-sig'))))
    counts = {}
    for row in rows:
        slot = counts.setdefault(row['snapshot'], {'rows': 0, 'churners': 0 if 'churn' in row else None})
        slot['rows'] += 1
        if 'churn' in row:
            slot['churners'] += int(row['churn'])
    report['files'][name] = {'source': git_path, 'sha256': hashlib.sha256(data).hexdigest(), 'rows': len(rows), 'columns': list(rows[0]), 'snapshots': counts}
    if 'labeled' in name:
        row = next(r for r in rows if r['StoreID'] == '296' and r['snapshot'] == '2012-07-01')
        report['example_row'] = row
        with (dest / 'actual_development_row.csv').open('w', newline='', encoding='utf-8') as output:
            writer = csv.DictWriter(output, fieldnames=list(row))
            writer.writeheader()
            writer.writerow(row)
(dest / 'provenance.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report, indent=2))

