import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {PresentationFile,FileBlob} from '@oai/artifact-tool';
const root='C:/Users/dzzz83/Documents/code/Reseller_Churn_Classification';
const build=path.join(root,'results/presentation-build');
const skill='C:/Users/dzzz83/.codex/plugins/cache/openai-primary-runtime/presentations/26.1013.11914/skills/presentations';
process.on('uncaughtException',e=>{console.error(e.stack);process.exit(1)});
const p=await PresentationFile.importPptx(await FileBlob.load(path.join(root,'results/presentation-output/reseller-churn-data-verification.pptx')));
const C={navy:'#142D42',teal:'#087F8C',paper:'#F6F7F5',muted:'#536674',line:'#D3DEDF',pale:'#E1EFED',gold:'#FBEDD6',amber:'#B87513',white:'#FFFFFF'};
async function png(s,name){const b=await p.export({slide:s,format:'png',scale:1});const a=Buffer.from(await b.arrayBuffer());await fs.writeFile(path.join(build,name),a);return crypto.createHash('sha256').update(a).digest('hex');}
const originalHashes=[];
for(let i=0;i<6;i++)originalHashes.push(await png(p.slides.items[i],`split-before-${i+1}.png`));
const snapshot=await p.inspect({kind:'shape,textbox,image',maxChars:1000000});
const records=snapshot.ndjson.split('\n').filter(Boolean).map(x=>JSON.parse(x));
const s3=p.slides.items[2];
p.delete(records.filter(x=>x.slideIndex===2&&/^(sh|im)\//.test(x.id??'')).map(x=>x.id));
const s4=p.slides.add(); const orderSnap=await p.inspect({kind:'slide',maxChars:100000}); const orderRows=orderSnap.ndjson.split('\n').filter(Boolean).map(x=>JSON.parse(x)).filter(x=>x.kind==='slide').sort((a,b)=>a.slideIndex-b.slideIndex); p.slides.reorder([0,1,2,6,3,4,5].map(i=>orderRows[i].id));
function text(s,v,x,y,w,h,size=28,color=C.navy,bold=false,align='left'){const a=s.shapes.add({geometry:'textbox',name:v.slice(0,50),position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});a.text=v;a.text.style={typeface:'Arial',fontSize:size,color,bold,alignment:align,verticalAlignment:'middle',insets:0};return a;}
function box(s,v,x,y,w,h,fill=C.pale,size=28,color=C.navy){const a=s.shapes.add({geometry:'rect',name:v.slice(0,50),position:{left:x,top:y,width:w,height:h},fill,line:{fill:C.line,width:1}});a.text=v;a.text.style={typeface:'Arial',fontSize:size,bold:true,color,alignment:'center',verticalAlignment:'middle',insets:12};return a;}
function arrow(s,a,b,from='right',to='left',kind='straight'){return s.shapes.connect(a,b,{kind,fromSide:from,toSide:to,line:{fill:C.teal,width:3},tail:{type:'triangle'}});}
function line(s,x,y,w,h,color=C.line,width=2){return s.shapes.add({geometry:'line',position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:color,width}});}
function frame(s,title,n,sub){s.background.fill=C.paper;text(s,title,72,52,1450,74,48,C.navy,true);if(sub)text(s,sub,74,135,1450,45,28,C.muted);text(s,String(n).padStart(2,'0'),1475,844,55,30,22,C.muted,false,'right');}
frame(s3,'Development snapshot windows',3);
text(s3,'Previous 12 months: features',75,145,630,45,30,C.teal,true);
text(s3,'Next 6 months: churn outcome',915,145,610,45,30,C.amber,true);
const x0=135,unit=48;
line(s3,x0,230,1296,0);
for(const [m,l] of [[0,'Jul 2011'],[6,'Jan 2012'],[12,'Jul 2012'],[18,'Jan 2013'],[24,'Jul 2013'],[27,'Oct 2013']]){
 line(s3,x0+m*unit,223,0,14);text(s3,l,x0+m*unit-65,190,130,32,23,C.muted,false,'center');
}
const rows=[['Jul 2011–Jun 2012','1 Jul 2012','Jul–Dec 2012'],['Oct 2011–Sep 2012','1 Oct 2012','Oct 2012–Mar 2013'],['Jan–Dec 2012','1 Jan 2013','Jan–Jun 2013'],['Apr 2012–Mar 2013','1 Apr 2013','Apr–Sep 2013']];
for(let i=0;i<4;i++){
 const y=300+i*125,start=x0+i*3*unit,boundary=start+12*unit;
 box(s3,rows[i][0],start,y,12*unit-12,72,C.pale,29);
 box(s3,rows[i][2],boundary+12,y,6*unit-12,72,C.gold,26);
 line(s3,boundary,y-4,0,80,C.navy,4);
 text(s3,rows[i][1],boundary-110,y-45,220,36,28,C.navy,true,'center');
}
text(s3,'Each snapshot pairs past purchasing behavior with a future churn label.',75,792,1430,40,28,C.muted);
s3.speakerNotes.text='The four frozen development snapshots are 1 July 2012, 1 October 2012, 1 January 2013, and 1 April 2013. The common calendar scale makes the overlapping histories and outcomes visible. Each teal box spans twelve months before the snapshot, and the amber box spans six months after it. For snapshot t: history [t minus 12 months,t), outcome [t,t plus 6 months). Month labels denote complete calendar months. Some features use only the preceding three months. Eligible resellers purchased in the preceding six months. A reseller may appear at multiple snapshots and may not qualify for every snapshot. Churn means no accepted purchase throughout the full outcome window. Outcomes provide historical development labels, not scoring inputs.\nSources: docs/input_contract.md, docs/model_and_results.md and reseller_churn/config.py on main.';
frame(s4,'Grouped validation and final test',4,'Example validation fold');
const all=box(s4,'Four development snapshots',75,272,395,115,C.pale,30);
const group=box(s4,'Group by\nStoreID',550,272,270,115,C.pale,31);
const tr=box(s4,'Training: resellers A, B, C\nAll their available snapshots',950,215,575,110,C.pale,28);
const va=box(s4,'Validation: resellers D, E\nAll their available snapshots',950,373,575,110,C.gold,28);
arrow(s4,all,group);arrow(s4,group,tr,'right','left','elbow');arrow(s4,group,va,'right','left','elbow');
text(s4,'The same reseller never appears on both sides of a fold.',75,519,1450,45,31,C.teal,true);
text(s4,'LATER FINAL TEST',75,604,1400,35,26,C.teal,true);
const fit=box(s4,'Final training\nAll 1,375 development rows',75,668,430,112,C.pale,28);
const test=box(s4,'Test snapshot\n1 Oct 2013',585,668,350,112,C.navy,31,C.white);
const outcome=box(s4,'Observe outcomes\nOct 2013–Mar 2014',1015,668,510,112,C.gold,29);
arrow(s4,fit,test);arrow(s4,test,outcome);
text(s4,'Test population: 492 resellers, including 46 churners',75,798,1450,37,28,C.muted);
s4.speakerNotes.text='The upper diagram is illustrative: letters A–E are examples, not real reseller identifiers and not actual split sizes. Grouping by StoreID keeps all available development snapshots for each reseller together within each validation fold. Each reseller can have fewer than four eligible snapshots. Training and validation can share development calendar dates. This grouped design measures performance for held-out reseller identities across mixed development periods; it is not strictly chronological validation. After methodology and cutoff decisions are fixed, the final ensemble fits all 1,375 development rows, including 212 churn cases. All development outcomes resolve by the prediction date 1 October 2013. Final test features use history before that date; the outcome interval is [1 October 2013,1 April 2014). There are 492 test resellers and 46 churners. Test identities may overlap development identities: final testing separates time, while grouped development validation separates identities. Original predictions and frozen decisions preceded original test-outcome access. October outcomes are now inspected, so later reuse is descriptive.\nSources: README.md, docs/input_contract.md, docs/model_and_results.md and reseller_churn/config.py on main.';
// Renumber existing features, metrics, results without changing their content.
const renumber=await p.inspect({kind:'shape,textbox',maxChars:1000000});
for(const r of renumber.ndjson.split('\n').filter(Boolean).map(x=>JSON.parse(x))){if(r.slideIndex>=4&&r.slideIndex<=6&&/^(04|05|06)$/.test(r.text??'')&&r.position?.left>1400)p.resolve(r.id).text=String(r.slideIndex+1).padStart(2,'0');}
for(let i=0;i<7;i++){const hash=await png(p.slides.items[i],`split-slide-${i+1}.png`);if(i<2&&hash!==originalHashes[i])throw Error(`Slide ${i+1} changed unexpectedly`);}
const candidate=path.join(build,'split-candidate.pptx');
await(await PresentationFile.exportPptx(p)).save(candidate);
const {finalizePresentation}=await import(pathToFileURL(path.join(skill,'container_tools/artifact_tool_utils.mjs')));
const r=await finalizePresentation({workspaceDir:root,candidatePath:candidate,finalPath:path.join(root,'results/presentation-output/reseller-churn-seven-slides.pptx'),pythonExecutable:'C:/Users/dzzz83/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe',integrityValidatorPath:path.join(skill,'container_tools/inspect_presentation_package_integrity.py'),layoutValidatorPath:path.join(skill,'container_tools/inspect_presentation_layout_geometry.py'),layoutArgs:['--expected-slide-size-emu','15240000,8572500','--validate-heading-fit','--require-native-table-slide','5','--require-native-table-slide','6','--require-native-table-slide','7'],explicitTotalSlideCount:7,requiredNativeTableOwnerSlides:[5,6,7],requiredNativeChartOwnerSlides:[7],nativeChartTargetApplication:'powerpoint',fontPolicy:{basis:'design',families:['Arial']},verifyArtifactToolImport:true,receiptPath:path.join(build,'split-validation.json')});
console.log(JSON.stringify({final:r.finalPath,findings:r.presentationLayout.finding_count,warnings:r.presentationLayout.warning_count}));



