import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {PresentationFile,FileBlob} from '@oai/artifact-tool';
const root='C:/Users/dzzz83/Documents/code/Reseller_Churn_Classification';
const build=path.join(root,'results/presentation-build');
const run=path.join(root,'results/dataset-regeneration-20261016');
const skill='C:/Users/dzzz83/.codex/plugins/cache/openai-primary-runtime/presentations/26.1013.11914/skills/presentations';
process.on('uncaughtException',e=>{console.error(e.stack);process.exit(1)});
const verification=JSON.parse(await fs.readFile(path.join(run,'verification.json'),'utf8'));
if(verification.status!=='passed')throw Error('Dataset verification must pass first');
const csv=(await fs.readFile(path.join(run,'actual_training_row.csv'),'utf8')).trim().split(/\r?\n/).map(x=>x.split(','));
const row=Object.fromEntries(csv[0].map((k,i)=>[k,csv[1][i]]));
if(row.StoreID!=='334'||row.snapshot!=='2012-07-01'||row.churn!=='1')throw Error('Unexpected source example');
const p=await PresentationFile.importPptx(await FileBlob.load(path.join(root,'results/presentation-output/reseller-churn-seven-slides.pptx')));
async function render(s,name){const b=await p.export({slide:s,format:'png',scale:1});const bytes=Buffer.from(await b.arrayBuffer());await fs.writeFile(path.join(build,name),bytes);return crypto.createHash('sha256').update(bytes).digest('hex');}
const before=[];for(let i=0;i<7;i++)before.push(await render(p.slides.items[i],`actual-before-${i+1}.png`));
const s=p.slides.add();
const order=await p.inspect({kind:'slide',maxChars:100000});
const records=order.ndjson.split('\n').filter(Boolean).map(x=>JSON.parse(x)).filter(x=>x.kind==='slide').sort((a,b)=>a.slideIndex-b.slideIndex);
p.slides.reorder([0,1,2,7,3,4,5,6].map(i=>records[i].id));
const C={navy:'#142D42',teal:'#087F8C',paper:'#F6F7F5',muted:'#536674',line:'#D3DEDF',pale:'#E1EFED',gold:'#FBEDD6',amber:'#B87513',white:'#FFFFFF'};
function text(v,x,y,w,h,size=28,color=C.navy,bold=false){const a=s.shapes.add({geometry:'textbox',name:v.slice(0,50),position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});a.text=v;a.text.style={typeface:'Arial',fontSize:size,color,bold,verticalAlignment:'middle',insets:0};return a;}
s.background.fill=C.paper;
text('Actual development row',72,52,1450,74,48,C.navy,true);
text(`Reseller ${row.StoreID}     Snapshot: 1 Jul 2012`,75,142,1450,46,32,C.teal,true);
const number=k=>Number(row[k]);
const amount=k=>number(k).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
const percent=k=>(number(k)*100).toFixed(2)+'%';
const values=[['Historical feature','Actual value'],
['Orders, previous 3 months',String(number('n_orders_3m'))],
['Revenue, previous 3 months',amount('revenue_3m')],
['Days since last order',String(number('recency_days'))],
['Bike revenue share, 12 months',percent('share_bikes')],
['Accessory revenue share, 12 months',percent('share_accessories')],
['Clothing revenue share, 12 months',percent('share_clothing')],
['Revenue, previous 12 months',amount('revenue_12m')],
['Weighted discount, 3 months',percent('weighted_discount_3m')],
['Discount change, 3 months','+'+(number('discount_change_3m')*100).toFixed(2)+' percentage points'],
['Discounted-line share, 12 months',percent('discounted_line_share_12m')]];
const t=s.tables.add({rows:values.length,columns:2,left:75,top:225,width:995,height:550,columnWidths:[610,385],values});
t.borders.assign({fill:C.line,width:1});
t.cells.block({row:0,column:0,rowCount:11,columnCount:2}).assign({margins:{top:6,bottom:6,left:16,right:16},textStyle:{typeface:'Arial',fontSize:26,color:C.navy}});
for(let r=0;r<11;r++){t.rows[r].height=50;for(let c=0;c<2;c++){const cell=t.getCell(r,c);cell.fill=r===0?C.navy:(r%2?C.white:'#EDF2F0');cell.text.style={typeface:'Arial',fontSize:26,color:r===0?C.white:C.navy,bold:r===0||c===1,verticalAlignment:'middle'};}}
text('PAST INFORMATION',1120,231,405,40,26,C.teal,true);
text('Jul 2011–Jun 2012',1120,285,405,48,31,C.navy,true);
text('Features available at\nthe snapshot',1120,345,405,82,28,C.muted);
text('FUTURE OUTCOME',1120,485,405,40,26,C.amber,true);
text('Churn = 1',1120,539,405,70,50,C.navy,true);
text('No accepted purchases\nduring Jul–Dec 2012',1120,627,405,90,30,C.amber,true);
text('Display values rounded. Source CSV retains full precision.',75,796,1420,40,26,C.muted);
text('04',1475,844,55,30,22,C.muted);
s.speakerNotes.text='Actual row from the regenerated fixed ten-feature development dataset, not an invented example. StoreID and snapshot identify the observation; the model inputs are the ten features in the table. The target churn=1 means no accepted purchase during [1 July 2012,1 January 2013). The target was only available once that outcome window ended. Eligibility requires a purchase during the preceding six months. Historical annual features use [1 July 2011,1 July 2012), while recent features use the preceding three months. Values on the slide are rounded to two decimal places for readability. Revenue units follow the source SubTotal values. Discount change is expressed in percentage points, not relative percentage change. All three discount observations are present for this example.\n\nFull-precision row:\n'+JSON.stringify(row,null,2)+'\n\nDataset: '+path.join(run,'verified-preparation/development.csv')+'\nDataset SHA-256: '+verification.development_csv_sha256+'\nVerification: '+path.join(run,'verification.json')+'\nSource exports and provenance: inputs/regeneration-20261016/source_manifest.json. The fixed code and formulas are unchanged on main. The seven base features and labels match the historical reference within numerical tolerance; all three discounts were independently checked using decimal source-line arithmetic. Exact parity against the original expanded training artifact cannot be established because that artifact/hash was not recovered. Source completeness and original order-time availability remain documented assumptions. No operational model retraining or final test outcome construction took place.';
const snap=await p.inspect({kind:'shape,textbox',maxChars:1000000});
for(const r of snap.ndjson.split('\n').filter(Boolean).map(x=>JSON.parse(x))){if(r.slideIndex>=4&&r.slideIndex<=7&&/^(04|05|06|07)$/.test(r.text??'')&&r.position?.left>1400)p.resolve(r.id).text=String(r.slideIndex+1).padStart(2,'0');}
for(let i=0;i<8;i++){const hash=await render(p.slides.items[i],`actual-slide-${i+1}.png`);if(i<3&&hash!==before[i])throw Error(`Unexpected change on slide ${i+1}`);}
const candidate=path.join(build,'actual-candidate.pptx');
await(await PresentationFile.exportPptx(p)).save(candidate);
const {finalizePresentation}=await import(pathToFileURL(path.join(skill,'container_tools/artifact_tool_utils.mjs')));
const r=await finalizePresentation({workspaceDir:root,candidatePath:candidate,finalPath:path.join(root,'results/presentation-output/reseller-churn-with-verified-row.pptx'),pythonExecutable:'C:/Users/dzzz83/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe',integrityValidatorPath:path.join(skill,'container_tools/inspect_presentation_package_integrity.py'),layoutValidatorPath:path.join(skill,'container_tools/inspect_presentation_layout_geometry.py'),layoutArgs:['--expected-slide-size-emu','15240000,8572500','--validate-heading-fit','--require-native-table-slide','4','--require-native-table-slide','6','--require-native-table-slide','7','--require-native-table-slide','8'],explicitTotalSlideCount:8,requiredNativeTableOwnerSlides:[4,6,7,8],requiredNativeChartOwnerSlides:[8],nativeChartTargetApplication:'powerpoint',fontPolicy:{basis:'design',families:['Arial']},verifyArtifactToolImport:true,receiptPath:path.join(build,'actual-verified-validation.json')});
console.log(JSON.stringify({final:r.finalPath,findings:r.presentationLayout.finding_count,warnings:r.presentationLayout.warning_count}));

