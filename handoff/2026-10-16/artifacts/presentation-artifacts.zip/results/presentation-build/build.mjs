import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {Presentation, PresentationFile} from '@oai/artifact-tool';

const root='C:/Users/dzzz83/Documents/code/Reseller_Churn_Classification';
const build=path.join(root,'results/presentation-build');
const out=path.join(root,'results/presentation-output');
const skill='C:/Users/dzzz83/.codex/plugins/cache/openai-primary-runtime/presentations/26.1013.11914/skills/presentations';
const python='C:/Users/dzzz83/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe';
const {finalizePresentation,applyPresentationChartFont}=await import(pathToFileURL(path.join(skill,'container_tools/artifact_tool_utils.mjs')));
const P=Presentation.create({slideSize:{width:1600,height:900}});
const C={navy:'#142D42',teal:'#087F8C',amber:'#B87513',red:'#B24B46',paper:'#F6F7F5',ink:'#20394B',muted:'#536674',line:'#D3DEDF',pale:'#E1EFED',gold:'#FBEDD6',white:'#FFFFFF'};
const source=(file)=>path.join(root,file);
function txt(s,text,x,y,w,h,size=28,color=C.ink,bold=false,align='left'){
 const a=s.shapes.add({geometry:'textbox',name:text.slice(0,55),position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});
 a.text=text;a.text.style={typeface:'Arial',fontSize:size,color,bold,alignment:align,verticalAlignment:'middle',insets:0,autoFit:'none'};return a;
}
function box(s,text,x,y,w,h,fill=C.pale,color=C.navy,size=28){
 const a=s.shapes.add({geometry:'rect',name:text.replaceAll('\n',' '),position:{left:x,top:y,width:w,height:h},fill,line:{fill:C.line,width:1}});
 a.text=text;a.text.style={typeface:'Arial',fontSize:size,bold:true,color,alignment:'center',verticalAlignment:'middle',insets:16};return a;
}
function arrow(s,a,b,from='right',to='left',color=C.teal){return s.shapes.connect(a,b,{kind:'straight',fromSide:from,toSide:to,line:{fill:color,width:3},tail:{type:'triangle'}});}
function slide(title,num,subtitle=''){
 const s=P.slides.add();s.background.fill=C.paper;
 txt(s,title,72,52,1456,74,48,C.navy,true);
 if(subtitle)txt(s,subtitle,74,135,1440,49,27,C.muted);
 txt(s,String(num).padStart(2,'0'),1475,844,55,30,22,C.muted,false,'right');return s;
}
function table(s,values,x,y,w,h,widths,font=25,header=25){
 const t=s.tables.add({rows:values.length,columns:values[0].length,left:x,top:y,width:w,height:h,columnWidths:widths,values});
 t.borders.assign({fill:C.line,width:1,style:'solid'});
 t.cells.block({row:0,column:0,rowCount:values.length,columnCount:values[0].length}).assign({textStyle:{typeface:'Arial',fontSize:font,color:C.ink},margins:{top:8,bottom:8,left:15,right:15},anchor:'center'});
 for(let r=0;r<values.length;r++)for(let c=0;c<values[0].length;c++){
  const z=t.getCell(r,c);z.fill=r===0?C.navy:(r%2?C.white:'#EDF2F0');
  z.text.style={typeface:'Arial',fontSize:r===0?header:font,color:r===0?C.white:C.ink,bold:r===0,verticalAlignment:'middle'};
 }
 return t;
}
function note(s,body,files){s.speakerNotes.text=body+'\n\nSources (main branch, commit ad573cfa5fddca628337fb9ce4deb3cdbe2e020b):\n'+files.map(source).join('\n');}

// 1: Overview and problem.
{
 const s=slide('Reseller churn prediction',1);
 txt(s,'Which resellers may\nstop purchasing?',74,195,740,160,66,C.navy,true);
 txt(s,'Goal: prioritize retention outreach\nbefore the next six months pass.',77,388,650,105,34);
 txt(s,'Churn means no accepted purchase\nduring the next six months.',77,563,650,90,31,C.teal,true);
 const bytes=await fs.readFile(path.join(build,'cover.png'));
 s.images.add({blob:bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength),contentType:'image/png',alt:'Illustration of bicycle resellers and an analyst reviewing retention',fit:'contain',position:{left:795,top:175,width:745,height:565}});
 txt(s,'Fixed model with 10 historical purchasing features',77,765,1400,45,28,C.muted);
 note(s,'The business goal is to rank eligible resellers for outreach. Eligibility requires an accepted purchase during the preceding six months. Labels look forward six months, while features use only earlier transactions. Scores are not validated calibrated individual risks. Cover illustration generated with the built-in image generation tool. Prompt: editorial bicycle reseller storefronts, one active and one quiet, retention analyst, navy/teal/amber on off-white, no text. Artwork: results/presentation-build/cover.png.', ['README.md','docs/input_contract.md']);
}
// 2: Native editable pipeline diagram.
{
 const s=slide('Pipeline overview',2,'Historical purchases become ranked churn scores');
 const a=box(s,'1  Source data\nOrders, stores, order lines',74,260,320,142);
 const b=box(s,'2  Validate inputs\nCoverage and matching IDs',445,260,320,142);
 const c=box(s,'3  Build 10 features\nOnly past transactions',816,260,320,142);
 const d=box(s,'4  Train fixed model\nAverage 5 boosting models',1187,260,339,142);
 arrow(s,a,b);arrow(s,b,c);arrow(s,c,d);
 const e=box(s,'5  Save predictions\nRank reseller scores',1187,522,339,142);
 const f=box(s,'6  Evaluate results\nApply the fixed cutoff',816,522,320,142);
 arrow(s,d,e,'bottom','top');arrow(s,e,f,'left','right');
 const o=box(s,'Supplied six-month\nobserved outcomes',445,522,320,142,C.gold);
 arrow(s,o,f,'right','left',C.amber);
 txt(s,'Balanced weights use training labels only',75,475,665,42,28,C.muted);
 txt(s,'Predictions precede outcome access. Evaluation reads saved scores.',75,744,1430,60,32,C.teal,true);
 note(s,'Final implementation lives in reseller_churn with thin CLI entry points in pipeline. Four CSV inputs: clean orders, stores, order headers, and order lines. Check coverage declarations and exact population joins. The ensemble averages probabilities for seeds 42, 78, 88, 1034, and 2026. Model settings are fixed. Native missing discount values remain missing. Evaluation does not retrain or optimize cutoffs. The historical training step and scoring feature construction are summarized here rather than represented as a runnable command sequence.', ['README.md','docs/input_contract.md','docs/model_and_results.md']);
}
// 3: Snapshot dates and information boundaries.
{
 const s=slide('Training, validation, and test split',3,'Development uses reseller groups. Testing uses a later snapshot.');
 txt(s,'DEVELOPMENT SNAPSHOTS',75,211,1000,40,26,C.teal,true);
 ['1 Jul 2012','1 Oct 2012','1 Jan 2013','1 Apr 2013'].forEach((v,i)=>box(s,v,75+i*370,268,340,78,C.pale,C.navy,31));
 txt(s,'1,375 account/snapshot rows, including 212 churn cases',76,365,1420,42,28,C.muted);
 const a=box(s,'Training reseller groups',75,440,530,82,C.pale);
 const b=box(s,'Validation reseller groups',650,440,530,82,C.gold);
 txt(s,'Same reseller stays in one group',75,536,1100,38,28,C.teal,true);
 txt(s,'Final model fits all development rows',75,588,1100,38,27,C.muted);
 txt(s,'ORIGINAL FINAL TEST',75,666,470,40,26,C.teal,true);
 box(s,'Snapshot\n1 Oct 2013',75,724,360,94,C.navy,C.white,29);
 box(s,'Outcome window\n1 Oct 2013 → 1 Apr 2014',480,724,670,94,C.pale,C.navy,29);
 txt(s,'492 resellers\n46 churners',1210,721,310,96,31,C.navy,true);
 note(s,'This is not a random chronological train/validation/test partition. Development contains the four frozen snapshots. Grouped validation keeps snapshots from the same StoreID together. The diagram does not claim specific fold counts or training/validation fractions, because the original final-methodology summary does not state them. All development labels resolve by 1 October 2013. For each snapshot t, feature history is [t minus 12 months, t), with recent measures over three months, and the eligible population purchased in [t minus six months, t). Churn means no accepted purchase in [t, t plus six months). The test outcome endpoint 1 April 2014 is excluded. October outcomes have already been inspected. Later reuse is descriptive.', ['README.md','docs/input_contract.md','docs/model_and_results.md']);
}
// 4: All ten feature meanings and learning signals.
{
 const s=slide('The ten model features',4,'Short windows capture recent behavior. Annual windows add context.');
 const rows=[['Feature','Short explanation','Training signal'],
 ['Order count, 3 months','Number of recent orders','Purchasing frequency'],
 ['Revenue, 3 months','Recent accepted order subtotals','Recent spending activity'],
 ['Recency','Days since the last order','Length of inactivity'],
 ['Bike share, 12 months','Bike revenue ÷ total revenue','Dependence on bike purchases'],
 ['Accessory share, 12 months','Accessory revenue ÷ total revenue','Accessory purchasing mix'],
 ['Clothing share, 12 months','Clothing revenue ÷ total revenue','Clothing purchasing mix'],
 ['Revenue, 12 months','Annual accepted order subtotals','Longer-term account scale'],
 ['Weighted discount, 3m','Discount weighted by gross value','Recent promotion exposure'],
 ['Discount change, 3m','Recent minus previous discount','Change in promotion exposure'],
 ['Discounted-line share, 12m','Fraction of lines with discount','Frequency of discounted buying']];
 const t=table(s,rows,74,212,1452,550,[435,505,512],25,26);
 t.cells.block({row:0,column:0,rowCount:11,columnCount:3}).assign({margins:{top:6,bottom:6,left:15,right:15}}); t.rows[0].height=50;for(let r=1;r<11;r++)t.rows[r].height=50;
 txt(s,'Usefulness describes potential signals, not proven gains from each feature.',76,789,1430,36,26,C.muted);
 note(s,'Technical feature order: n_orders_3m, revenue_3m, recency_days, share_bikes, share_accessories, share_clothing, revenue_12m, weighted_discount_3m, discount_change_3m, discounted_line_share_12m. Gross line value is quantity times unit price. Discount change compares the recent three months with the preceding three months. All category shares use annual SubTotal revenue. Missing discount observations remain missing rather than becoming zero. The signal descriptions are explanatory hypotheses, not causal claims or measured incremental performance improvements. Later held-out SHAP findings on main report largest mean absolute attributions for recent revenue (8.48 probability points), bike share (5.81), and recency (5.04). These are model attribution magnitudes and do not establish incremental feature usefulness. They are not substituted for the frozen original model results.', ['docs/input_contract.md','reseller_churn/config.py','docs/model_and_results.md']);
}
// 5: Metrics, in the user's requested order.
{
 const s=slide('Evaluation metrics',5,'Priority: recall first, precision second, then F1');
 const vals=[['Metric','Plain-language question','Calculation'],['Recall','How many churners did we catch?','Caught ÷ all churners'],['Precision','How many alerts were correct?','Caught ÷ all alerts'],['F1','How well do recall and precision balance?','2 × precision × recall\n÷ (precision + recall)']];
 const t=table(s,vals,74,227,1452,285,[260,720,472],29,28);t.rows[0].height=54;for(let r=1;r<4;r++)t.rows[r].height=77;
 txt(s,'READING THE ERRORS',75,560,900,37,26,C.teal,true);
 table(s,[['Model decision','Actually churned','Actually retained'],['Alert','Caught churner','False alert'],['No alert','Missed churner','Correct non-alert']],75,619,990,171,[330,330,330],27,26);
 txt(s,'Precision target\nAt least 30%',1135,623,390,105,35,C.navy,true);
 txt(s,'False alerts measure\noutreach workload',1135,739,390,65,26,C.amber,true);
 note(s,'Recall = TP/(TP+FN). Precision = TP/(TP+FP). F1 = 2TP/(2TP+FP+FN), equivalent to the harmonic mean of precision and recall. The original primary cutoff was selected using grouped development results with an intended 30% precision floor. The minimum precision column in the results is that development target, not a guarantee or observed test metric. False alerts are retained resellers who receive an alert. Recall is the primary priority requested by the user. ROC-AUC and average precision are intentionally excluded from this deck.', ['docs/model_and_results.md','reseller_churn/evaluation.py']);
}
// 6: Original final test, native chart and full requested metric table.
{
 const s=slide('Original final test results',6,'October 2013 test: 492 resellers, 46 churners, primary cutoff 0.06');
 const ch=s.charts.add('bar',{position:{left:75,top:224,width:945,height:340},categories:['Caught churners','Missed churners','False alerts'],series:[{name:'Resellers',values:[43,3,108],fill:C.teal,points:[{idx:0,fill:C.teal},{idx:1,fill:C.red},{idx:2,fill:C.amber}]}],hasLegend:false,barOptions:{direction:'bar',grouping:'clustered',gapWidth:85},chartFill:C.paper,plotAreaFill:C.paper,xAxis:{visible:true,min:0,max:120,majorUnit:30,numberFormatCode:'0',textStyle:{fontSize:24,fill:C.muted},majorGridlines:{fill:C.line,width:1}},yAxis:{visible:true,textStyle:{fontSize:27,fill:C.ink},majorGridlines:null},dataLabels:{showValue:true,position:'outEnd',numberFormatCode:'0',textStyle:{fontSize:29,bold:true,fill:C.navy}}});
 applyPresentationChartFont(ch,{fontFamily:'Arial',availableFonts:['Arial']});
 txt(s,'93.48%',1100,235,425,85,72,C.teal,true);txt(s,'Recall',1105,320,410,45,31,C.navy,true);
 txt(s,'28.48%',1100,405,425,75,60,C.amber,true);txt(s,'Precision',1105,482,410,45,31,C.navy,true);
 const vals=[['Minimum\nprecision','Actual\nprecision','Recall','F1','Caught /\nchurners','Missed /\nchurners','False\nalerts','Total\nresellers'],['30.00%','28.48%','93.48%','43.65%','43 / 46','3 / 46','108','492']];
 const t=table(s,vals,75,611,1450,133,[180,180,165,165,210,200,175,175],29,25);t.rows[0].height=74;t.rows[1].height=59;
 txt(s,'Precision missed the 30% target. Recently active reseller precision was 7.55%.',76,768,1450,38,27,C.amber,true);
 txt(s,'October outcomes are already inspected. Further comparisons are descriptive.',76,814,1420,30,23,C.muted);
 note(s,'Original final model: ten-feature histogram gradient boosting, SubTotal revenue, mean probabilities over five frozen seeds. Original primary cutoff 0.06. Test cohort = 492 resellers with 46 churners and 446 retained resellers. TP=43, FN=3, FP=108, TN=338. Alerts=151. Recall=43/46=93.47826087%. Precision=43/151=28.47682119%. F1=86/197=43.65482234%. Minimum precision is the intended 30% development target. Counts: 43+3=46 churners; 108+338=446 retained; total=492. Chart categories overlap by purpose only in the sense caught and missed partition churners, while false alerts belong to retained accounts. The chart does not portray an exhaustive population partition, because correct non-alerts are not plotted. Recently active accounts: 8 caught, 3 missed, 98 false alerts, yielding 72.73% recall and 7.55% precision. Previously inactive accounts contain 35 of 46 churners and all are caught. This mix limits interpretation of aggregate recall. Original predictions preceded outcome access, but October outcomes are now inspected and further comparisons are descriptive. No model was trained and no new evaluation or protected outcomes were constructed for this presentation.', ['docs/model_and_results.md','reseller_churn/config.py']);
}

await fs.mkdir(out,{recursive:true});
await fs.writeFile(path.join(build,'deck.json'),JSON.stringify(P.toProto()));
for(const [i,s] of P.slides.items.entries()){
 const png=await P.export({slide:s,format:'png',scale:1});
 await fs.writeFile(path.join(build,`slide-${i+1}.png`),new Uint8Array(await png.arrayBuffer()));
 console.log(`Rendered slide ${i+1}`);
}
const candidate=path.join(build,'candidate.pptx');
await(await PresentationFile.exportPptx(P)).save(candidate);
const result=await finalizePresentation({workspaceDir:root,candidatePath:candidate,finalPath:path.join(out,'reseller-churn-final.pptx'),pythonExecutable:python,integrityValidatorPath:path.join(skill,'container_tools/inspect_presentation_package_integrity.py'),layoutValidatorPath:path.join(skill,'container_tools/inspect_presentation_layout_geometry.py'),layoutArgs:['--expected-slide-size-emu','15240000,8572500','--validate-bullet-geometry','--validate-heading-fit','--require-native-table-slide','4','--require-native-table-slide','5','--require-native-table-slide','6'],explicitTotalSlideCount:6,requiredNativeTableOwnerSlides:[4,5,6],requiredNativeChartOwnerSlides:[6],materializeLiteralChartWorkbooks:true,nativeChartTargetApplication:'powerpoint',fontPolicy:{basis:'design',families:['Arial']},verifyArtifactToolImport:true,receiptPath:path.join(build,'validation-final.json')});
console.log(JSON.stringify(result));



