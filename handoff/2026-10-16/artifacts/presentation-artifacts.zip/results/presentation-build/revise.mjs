import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import crypto from 'node:crypto';
import {Presentation,PresentationFile,FileBlob} from '@oai/artifact-tool';
const root='C:/Users/dzzz83/Documents/code/Reseller_Churn_Classification';
const build=path.join(root,'results/presentation-build');
const skill='C:/Users/dzzz83/.codex/plugins/cache/openai-primary-runtime/presentations/26.1013.11914/skills/presentations';
const source=path.join(root,'results/presentation-output/reseller-churn-final.pptx');
const p=await PresentationFile.importPptx(await FileBlob.load(source));
const C={navy:'#142D42',teal:'#087F8C',paper:'#F6F7F5',muted:'#536674',line:'#D3DEDF',pale:'#E1EFED',gold:'#FBEDD6',amber:'#B87513'};
async function png(s,name){const b=await p.export({slide:s,format:'png',scale:1});const data=Buffer.from(await b.arrayBuffer());await fs.writeFile(path.join(build,name),data);return crypto.createHash('sha256').update(data).digest('hex');}
process.on('uncaughtException',e=>{console.error(e.message);process.exit(1)}); const before=[];
for(let i=0;i<6;i++)before.push(await png(p.slides.items[i],`revision-before-${i+1}.png`));
console.log('Before previews saved');
function text(s,value,x,y,w,h,size=32,color=C.navy,bold=false){const a=s.shapes.add({geometry:'textbox',position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});a.text=value;a.text.style={typeface:'Arial',fontSize:size,color,bold,insets:0,verticalAlignment:'middle'};return a;}
function box(s,value,x,y,w,h,fill=C.pale,size=34){const a=s.shapes.add({geometry:'rect',position:{left:x,top:y,width:w,height:h},fill,line:{fill:C.line,width:1}});a.text=value;a.text.style={typeface:'Arial',fontSize:size,bold:true,color:C.navy,alignment:'center',verticalAlignment:'middle',insets:16};return a;}
function arrow(s,a,b,from='right',to='left',color=C.teal){return s.shapes.connect(a,b,{kind:'straight',fromSide:from,toSide:to,line:{fill:color,width:4},tail:{type:'triangle'}});}
for(let i=0;i<2;i++){
 const s=p.slides.items[i];
 const snap=await p.inspect({kind:'textbox,shape,image',maxChars:1000000}); const ids=snap.ndjson.split('\n').filter(Boolean).map(x=>JSON.parse(x)).filter(x=>x.slideIndex===i && /^(sh|im)\//.test(x.id??'')).map(x=>x.id);
 console.log('Clearing slide',i+1,ids.length);
 p.delete(ids);
 s.background.fill=C.paper;
}
{
 const s=p.slides.items[0];
 text(s,'Reseller churn\nprediction',74,225,600,180,76,C.navy,true);
 text(s,'Identify resellers likely to stop\npurchasing within six months.',77,461,600,114,35,C.teal);
 const bytes=await fs.readFile(path.join(build,'bicycle-shop.jpg'));
 s.images.add({blob:bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength),contentType:'image/jpeg',alt:'Real photograph of a bicycle shop, by Alextredz / Tredz',fit:'contain',position:{left:710,top:180,width:820,height:547}});
 text(s,'01',1475,844,55,30,22,C.muted);
 s.speakerNotes.text='Project overview: rank eligible resellers for retention outreach using historical purchasing behavior. Churn means no accepted purchase during the following six months. The photograph illustrates a bicycle retailer and does not depict an account from the dataset.\n\nPhoto credit: Alextredz / Tredz, Bike workshop - bicycle repair shop, 4 June 2021. Source: https://commons.wikimedia.org/wiki/File:Bike_workshop_-_bicycle_repair_shop.jpg . Original creator website: https://www.tredz.co.uk/ . License: CC BY-SA 4.0, https://creativecommons.org/licenses/by-sa/4.0/ . Photograph reproduced without cropping, color adjustment, or other image modification; resized proportionally.\n\nProject sources: README.md and docs/input_contract.md on main, commit ad573cfa5fddca628337fb9ce4deb3cdbe2e020b.';
}
{
 const s=p.slides.items[1];
 text(s,'Pipeline overview',72,52,1456,74,48,C.navy,true);
 const a=box(s,'Purchase data',100,240,400,120);
 const b=box(s,'Data checks',600,240,400,120);
 const c=box(s,'10 features',1100,240,400,120);
 const d=box(s,'Train model',1100,540,400,120);
 const e=box(s,'Churn scores',600,540,400,120);
 const f=box(s,'Evaluation',100,540,400,120);
 arrow(s,a,b);arrow(s,b,c);arrow(s,c,d,'bottom','top');arrow(s,d,e,'left','right');arrow(s,e,f,'left','right');
 const o=box(s,'Observed outcomes',100,740,400,70,C.gold,27);
 arrow(s,o,f,'top','bottom',C.amber);
 text(s,'02',1475,844,55,30,22,C.muted);
 s.speakerNotes.text='1. Purchase data: clean orders, stores, order headers, and order lines. 2. Data checks: declared source coverage and matching order/reseller populations. 3. Ten historical features, all using information before each scoring snapshot. Development preparation also constructs approved historical training labels. 4. Fixed histogram gradient boosting ensemble, averaging five seeds. Balanced weights use training labels only. Missing discount values remain missing. 5. Save ranked churn scores before outcome access. 6. Evaluate saved predictions against separately supplied observed outcomes using the frozen primary cutoff 0.06. Evaluation does not train or optimize cutoffs. The compact flow summarizes historical training and later scoring, rather than showing every input dependency.\n\nSources: README.md, docs/input_contract.md, docs/model_and_results.md, reseller_churn/config.py on main, commit ad573cfa5fddca628337fb9ce4deb3cdbe2e020b.';
}
for(let i=0;i<6;i++){
 const after=await png(p.slides.items[i],`revision-slide-${i+1}.png`);
 if(i>=2&&after!==before[i])throw Error(`Unrelated slide ${i+1} changed visually`);
}
console.log('Slides 3–6 render identically before and after');
const candidate=path.join(build,'revision-candidate.pptx');
await(await PresentationFile.exportPptx(p)).save(candidate);
const {finalizePresentation}=await import(pathToFileURL(path.join(skill,'container_tools/artifact_tool_utils.mjs')));
const r=await finalizePresentation({workspaceDir:root,candidatePath:candidate,finalPath:path.join(root,'results/presentation-output/reseller-churn-revised-slides-1-2.pptx'),pythonExecutable:'C:/Users/dzzz83/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe',integrityValidatorPath:path.join(skill,'container_tools/inspect_presentation_package_integrity.py'),layoutValidatorPath:path.join(skill,'container_tools/inspect_presentation_layout_geometry.py'),layoutArgs:['--expected-slide-size-emu','15240000,8572500','--validate-heading-fit','--require-native-table-slide','4','--require-native-table-slide','5','--require-native-table-slide','6'],explicitTotalSlideCount:6,requiredNativeTableOwnerSlides:[4,5,6],requiredNativeChartOwnerSlides:[6],nativeChartTargetApplication:'powerpoint',fontPolicy:{basis:'design',families:['Arial']},verifyArtifactToolImport:true,receiptPath:path.join(build,'revision-validation.json')});
console.log(JSON.stringify({finalPath:r.finalPath,layout:r.presentationLayout,import:r.firstPartyImport?.passed}));

