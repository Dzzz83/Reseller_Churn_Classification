# Grouped-validation component ablation

This is a controlled exploratory follow-up on development data. It separates
individual additions, removal from the complete candidate, and selected
interactions. It does not assign causal or uniquely additive percentages of
the previous adaptive procedure's gain to individual components.

## Design and data boundary

Fourteen predefined configurations cover five binary changes: overdue ratio,
annual order count, purchase-gap variation, seven tree leaves instead of 31,
and L2=1 instead of zero. They include baseline, each single addition, the
complete candidate, each one-component removal, cadence-only and the two
regularization changes together. The complete candidate here is the previously
frozen 13-feature cadence/regularization configuration, not the earlier
16-feature spending-plus-cadence candidate.

Same approved development rows, reseller grouping, three repetition seeds,
five outer folds, three inner folds, five estimator seeds, and training-only
weights are preserved. Each configuration selects its own cutoff using inner
OOF predictions, maximizing precision subject to recall strictly >90%.
Outer validation outcomes do not tune cutoffs or fitted parameters. Thus
decision differences include the configuration's training-only cutoff
adaptation. AP is reported separately as a ranking measure; no outer cutoff
is chosen to force matched observed recall.

Four compatible configurations reuse saved predictions and model identities
after source, protocol, population, and exact split checks. Ten additional
configurations require 300 new estimator fits;
120 estimator fits are represented by reused evidence.
Only development artifacts are inputs. No test scoring rows, outcomes, or
evaluation are used. The operational model and frozen research candidate are
unchanged; this study recommends rather than automatically replaces anything.

## Configuration results

Each value averages repeat-level pooled outer metrics, with fold-specific
training-selected cutoffs. Do not treat repeat predictions as independent
new customers. Recall feasibility is assessed in every repetition, not just
the displayed mean. Full repeat/fold/subgroup results are retained in CSVs.

| Configuration | Changes | Recall | Precision | AP | Repeats >90% recall |
| --- | --- | ---: | ---: | ---: | ---: |
| f00 | baseline | 87.10% | 27.65% | 0.2950 | 0/1 |
| f01 | overdue_ratio | 90.32% | 28.19% | 0.2942 | 1/1 |
| f02 | n_orders_12m | 89.25% | 27.95% | 0.3143 | 0/1 |
| f04 | gap_cv | 94.62% | 28.66% | 0.2881 | 1/1 |
| f07 | overdue_ratio + n_orders_12m + gap_cv | 90.32% | 28.00% | 0.3132 | 1/1 |
| f08 | seven_leaves | 87.10% | 27.65% | 0.2950 | 0/1 |
| f15 | overdue_ratio + n_orders_12m + gap_cv + seven_leaves | 90.32% | 28.00% | 0.3132 | 1/1 |
| f16 | l2_one | 90.32% | 27.81% | 0.3158 | 1/1 |
| f23 | overdue_ratio + n_orders_12m + gap_cv + l2_one | 89.25% | 27.76% | 0.3063 | 0/1 |
| f24 | seven_leaves + l2_one | 90.32% | 27.81% | 0.3158 | 1/1 |
| f27 | overdue_ratio + n_orders_12m + seven_leaves + l2_one | 91.40% | 28.62% | 0.3023 | 1/1 |
| f29 | overdue_ratio + gap_cv + seven_leaves + l2_one | 88.17% | 28.18% | 0.2949 | 0/1 |
| f30 | n_orders_12m + gap_cv + seven_leaves + l2_one | 91.40% | 28.05% | 0.3024 | 1/1 |
| f31 | overdue_ratio + n_orders_12m + gap_cv + seven_leaves + l2_one | 89.25% | 27.76% | 0.3063 | 0/1 |

## Contributions and interactions

"add" compares a single addition with baseline. "remove" reports complete
candidate minus candidate without that change: a positive number means the
component helps when restored to the full context. It is not the effect of
deletion with reversed sign. Bundle contrasts hold the other bundle fixed.
Interactions are difference-in-differences, not individual-feature importance.

| Contrast: positive means component helps | Precision difference (points) | Adjusted interval (points) | Recall difference (points) | AP difference |
| --- | ---: | --- | ---: | ---: |
| add_overdue_ratio | +0.54 | [-1.73, +3.23] | +3.23 | -0.0008 |
| remove_overdue_ratio | -0.29 | [-1.55, +0.71] | -2.15 | +0.0039 |
| add_n_orders_12m | +0.30 | [-2.13, +3.03] | +2.15 | +0.0193 |
| remove_n_orders_12m | -0.42 | [-1.71, +1.55] | +1.08 | +0.0114 |
| add_gap_cv | +1.02 | [-1.59, +3.87] | +7.53 | -0.0069 |
| remove_gap_cv | -0.86 | [-2.62, +0.62] | -2.15 | +0.0040 |
| add_seven_leaves | +0.00 | [+0.00, +0.00] | +0.00 | +0.0000 |
| remove_seven_leaves | +0.00 | [+0.00, +0.00] | +0.00 | +0.0000 |
| add_l2_one | +0.17 | [-1.44, +1.96] | +3.23 | +0.0208 |
| remove_l2_one | -0.24 | [-1.26, +0.48] | -1.08 | -0.0069 |
| cadence_alone | +0.35 | [-2.64, +3.03] | +3.23 | +0.0181 |
| regularization_alone | +0.17 | [-1.44, +1.96] | +3.23 | +0.0208 |
| cadence_with_regularization | -0.06 | [-2.89, +2.38] | -1.08 | -0.0095 |
| regularization_with_cadence | -0.24 | [-1.26, +0.48] | -1.08 | -0.0069 |
| cadence_regularization_interaction | -0.41 | [-2.69, +1.44] | -4.30 | -0.0277 |
| leaves_l2_interaction_without_cadence | +0.00 | [+0.00, +0.00] | +0.00 | +0.0000 |
| leaves_l2_interaction_with_cadence | +0.00 | [+0.00, +0.00] | +0.00 | +0.0000 |

Precision intervals use 500 paired whole-reseller
bootstrap draws, carrying all snapshots and repetitions together. Percentile
tails use alpha/(2*17), a Bonferroni adjustment for the 17 predefined precision
contrasts. These are approximate family-adjusted conditional intervals, not
exact finite-sample coverage guarantees. They exclude refitting/reselection
uncertainty and do not correct for earlier exploratory development inspection.
Recall intervals in CSVs are marginal 95% exploratory intervals; AP differences
are point estimates without significance claims. No claim of reliable AP or
recall improvement is made from an unadjusted interval.

Adjusted intervals entirely above zero: `[]`.
Adjusted intervals entirely below zero: `[]`.
Intervals crossing zero mean insufficient evidence in that context; they do
not prove the component has no effect. Different single-addition and removal
effects indicate context dependence. Contributions cannot be summed as unique
shares of the earlier adaptive selection procedure's improvement.

## Cutoff contribution

On unchanged baseline model scores, replacing original 0.06 with the common
inner high-recall selection rule changes mean recall from
81.72% to 87.10%,
and precision from 26.95% to
27.65%. AP is unchanged because score
rankings are unchanged. This demonstrates the cost of the high-recall operating
rule, not a ranking improvement. Feature/regularization comparisons above all
use the same selection rule, so they are not merely compared with the old
0.06 operating point.

## Interpretation and verification

Use per-repeat recall feasibility together with precision, ranking AP, error
tradeoffs, and adjusted uncertainty. A component that improves precision by
sacrificing the >90% objective is not automatically useful. Retaining the
previous candidate while inspecting simpler hypotheses does not validate
those hypotheses prospectively; a new winner chosen from these outer scores
would need a separate, appropriately frozen development comparison.

Independent checks verified 126 metric rows, all
inner cutoff choices, outer/inner reseller isolation, matched populations,
exact reuse of scores/cutoffs, new/reused fit accounting, and artifact hashes.
The source preparation and shared fitting code remain unchanged. Synthetic
tests/smoke establish execution correctness, not model quality. The full
repository suite remains blocked by the previously documented config
module/package collision; focused research tests are run independently.

No final-test evaluation, automatic model replacement, push, or merge occurred.
