# Grouped-validation component ablation

This is a controlled exploratory follow-up on development data. It separates
individual additions, removal from the complete candidate, and selected
interactions. It does not assign causal or uniquely additive percentages of
the previous adaptive procedure's gain to individual components.

## Design and data boundary

Fourteen predefined configurations cover five binary changes: overdue ratio,
annual order count, purchase-gap variation, seven tree leaves instead of 31,
and L2=1 instead of zero. They include baseline, each single addition, the
complete candidate, each one-component removal, cadence-only and the two
regularization changes together. The complete candidate here is the previously
frozen 13-feature cadence/regularization configuration, not the earlier
16-feature spending-plus-cadence candidate.

Same approved development rows, reseller grouping, three repetition seeds,
five outer folds, three inner folds, five estimator seeds, and training-only
weights are preserved. Each configuration selects its own cutoff using inner
OOF predictions, maximizing precision subject to recall strictly >90%.
Outer validation outcomes do not tune cutoffs or fitted parameters. Thus
decision differences include the configuration's training-only cutoff
adaptation. AP is reported separately as a ranking measure; no outer cutoff
is chosen to force matched observed recall.

Four compatible configurations reuse saved predictions and model identities
after source, protocol, population, and exact split checks. Ten additional
configurations require 3000 new estimator fits;
1200 estimator fits are represented by reused evidence.
Only development artifacts are inputs. No test scoring rows, outcomes, or
evaluation are used. The operational model and frozen research candidate are
unchanged; this study recommends rather than automatically replaces anything.

## Configuration results

Each value averages repeat-level pooled outer metrics, with fold-specific
training-selected cutoffs. Do not treat repeat predictions as independent
new customers. Recall feasibility is assessed in every repetition, not just
the displayed mean. Full repeat/fold/subgroup results are retained in CSVs.

| Configuration | Changes | Recall | Precision | AP | Repeats >90% recall |
| --- | --- | ---: | ---: | ---: | ---: |
| f00 | baseline | 91.51% | 27.16% | 0.4843 | 3/3 |
| f01 | overdue_ratio | 91.67% | 28.68% | 0.5012 | 2/3 |
| f02 | n_orders_12m | 91.19% | 27.86% | 0.4982 | 2/3 |
| f04 | gap_cv | 92.14% | 28.89% | 0.5107 | 3/3 |
| f07 | overdue_ratio + n_orders_12m + gap_cv | 91.04% | 29.25% | 0.5221 | 2/3 |
| f08 | seven_leaves | 94.34% | 26.72% | 0.5339 | 3/3 |
| f15 | overdue_ratio + n_orders_12m + gap_cv + seven_leaves | 95.60% | 28.55% | 0.5552 | 3/3 |
| f16 | l2_one | 91.19% | 27.18% | 0.4982 | 3/3 |
| f23 | overdue_ratio + n_orders_12m + gap_cv + l2_one | 89.47% | 29.39% | 0.5272 | 2/3 |
| f24 | seven_leaves + l2_one | 94.03% | 27.06% | 0.5394 | 3/3 |
| f27 | overdue_ratio + n_orders_12m + seven_leaves + l2_one | 93.71% | 28.18% | 0.5564 | 3/3 |
| f29 | overdue_ratio + gap_cv + seven_leaves + l2_one | 95.28% | 29.05% | 0.5590 | 3/3 |
| f30 | n_orders_12m + gap_cv + seven_leaves + l2_one | 94.65% | 28.43% | 0.5595 | 3/3 |
| f31 | overdue_ratio + n_orders_12m + gap_cv + seven_leaves + l2_one | 94.65% | 29.31% | 0.5597 | 3/3 |

## Main findings

Components with adjusted positive precision intervals both alone and in the
full context: `['overdue_ratio', 'gap_cv']`. These are contextual operational
effects under the shared training-only cutoff rule, not causal purchasing
effects or uniquely additive fractions of the earlier improvement.

| Component | Precision effect added alone (points) | Precision effect included in full context (points) | Recall effect included in full context (points) |
| --- | ---: | ---: | ---: |
| overdue_ratio | +1.52 | +0.88 | +0.00 |
| n_orders_12m | +0.71 | +0.26 | -0.63 |
| gap_cv | +1.74 | +1.14 | +0.94 |
| seven_leaves | -0.44 | -0.08 | +5.19 |
| l2_one | +0.02 | +0.77 | -0.94 |

The simplest individual additions showing an adjusted precision gain and
meeting >90% recall in every repetition are `['gap_cv']`. This is a
follow-up simplification hypothesis, not proof of equivalence to the full
candidate and not a new automatically selected replacement.

For the complete candidate, the three cadence features and both regularization
changes yield 94.65% recall and
29.31% precision. Baseline values are
91.51% and 27.16%.
These are fixed-configuration ablations; the earlier 29.74%/91.51% result
describes adaptive configuration selection and is a different estimand.

Fewer leaves have an observed full-context recall contribution of
+5.19 points;
without that change the full-minus-leaves configuration has mean recall
89.47%, reaching >90% in only
2/3
repetitions. Precision contribution is
-0.08 points.
Thus recall feasibility and precision contribution must be assessed separately.
Recall differences are descriptive secondary evidence here.

Annual count and L2 should not be called useless from intervals crossing zero.
Those intervals also do not establish that removing them preserves useful
performance. None of the tested interaction precision intervals excludes zero
in the canonical run, so there is no adjusted evidence for a specific synergy.

## Contributions and interactions

"add" compares a single addition with baseline. "remove" reports complete
candidate minus candidate without that change: a positive number means the
component helps when restored to the full context. It is not the effect of
deletion with reversed sign. Bundle contrasts hold the other bundle fixed.
Interactions are difference-in-differences, not individual-feature importance.

| Contrast: positive means component helps | Precision difference (points) | Adjusted interval (points) | Recall difference (points) | AP difference |
| --- | ---: | --- | ---: | ---: |
| add_overdue_ratio | +1.52 | [+0.42, +2.69] | +0.16 | +0.0169 |
| remove_overdue_ratio | +0.88 | [+0.17, +1.63] | +0.00 | +0.0002 |
| add_n_orders_12m | +0.71 | [-0.33, +1.84] | -0.31 | +0.0138 |
| remove_n_orders_12m | +0.26 | [-0.28, +0.83] | -0.63 | +0.0007 |
| add_gap_cv | +1.74 | [+0.62, +2.97] | +0.63 | +0.0263 |
| remove_gap_cv | +1.14 | [+0.36, +1.98] | +0.94 | +0.0034 |
| add_seven_leaves | -0.44 | [-1.56, +0.72] | +2.83 | +0.0496 |
| remove_seven_leaves | -0.08 | [-1.38, +1.32] | +5.19 | +0.0326 |
| add_l2_one | +0.02 | [-0.86, +0.87] | -0.31 | +0.0139 |
| remove_l2_one | +0.77 | [-0.00, +1.52] | -0.94 | +0.0045 |
| cadence_alone | +2.09 | [+0.69, +3.60] | -0.47 | +0.0377 |
| regularization_alone | -0.10 | [-1.23, +1.07] | +2.52 | +0.0551 |
| cadence_with_regularization | +2.25 | [+1.07, +3.52] | +0.63 | +0.0203 |
| regularization_with_cadence | +0.06 | [-1.01, +1.18] | +3.62 | +0.0377 |
| cadence_regularization_interaction | +0.16 | [-1.06, +1.41] | +1.10 | -0.0174 |
| leaves_l2_interaction_without_cadence | +0.32 | [-0.67, +1.33] | +0.00 | -0.0084 |
| leaves_l2_interaction_with_cadence | +0.62 | [-0.59, +1.83] | +0.63 | -0.0006 |

Precision intervals use 50,000 paired whole-reseller
bootstrap draws, carrying all snapshots and repetitions together. Percentile
tails use alpha/(2*17), a Bonferroni adjustment for the 17 predefined precision
contrasts. These are approximate family-adjusted conditional intervals, not
exact finite-sample coverage guarantees. They exclude refitting/reselection
uncertainty and do not correct for earlier exploratory development inspection.
Recall intervals in CSVs are marginal 95% exploratory intervals; AP differences
are point estimates without significance claims. No claim of reliable AP or
recall improvement is made from an unadjusted interval.

Adjusted intervals entirely above zero: `['add_overdue_ratio', 'remove_overdue_ratio', 'add_gap_cv', 'remove_gap_cv', 'cadence_alone', 'cadence_with_regularization']`.
Adjusted intervals entirely below zero: `[]`.
Intervals crossing zero mean insufficient evidence in that context; they do
not prove the component has no effect. Different single-addition and removal
effects indicate context dependence. Contributions cannot be summed as unique
shares of the earlier adaptive selection procedure's improvement.

## Cutoff contribution

On unchanged baseline model scores, replacing original 0.06 with the common
inner high-recall selection rule changes mean recall from
77.36% to 91.51%,
and precision from 32.96% to
27.16%. AP is unchanged because score
rankings are unchanged. This demonstrates the cost of the high-recall operating
rule, not a ranking improvement. Feature/regularization comparisons above all
use the same selection rule, so they are not merely compared with the old
0.06 operating point.

## Interpretation and verification

Use per-repeat recall feasibility together with precision, ranking AP, error
tradeoffs, and adjusted uncertainty. A component that improves precision by
sacrificing the >90% objective is not automatically useful. Retaining the
previous candidate while inspecting simpler hypotheses does not validate
those hypotheses prospectively; a new winner chosen from these outer scores
would need a separate, appropriately frozen development comparison.

Independent checks verified 756 metric rows, all
inner cutoff choices, outer/inner reseller isolation, matched populations,
exact reuse of scores/cutoffs, new/reused fit accounting, and artifact hashes.
The source preparation and shared fitting code remain unchanged. Synthetic
tests/smoke establish execution correctness, not model quality. The full
repository suite remains blocked by the previously documented config
module/package collision; focused research tests are run independently.

No final-test evaluation, automatic model replacement, push, or merge occurred.
