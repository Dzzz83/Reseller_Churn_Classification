# Regenerated fixed ten-feature development dataset

Final dataset: `verified-preparation/development.csv`.
Verification: `verification.json`. Preparation provenance: `verified-preparation/manifest.json`.
Selected full-precision row: `actual_training_row.csv` (StoreID 334, snapshot 2012-07-01).

## Source and scope

Read-only SELECT exports from the existing local SQL Server database `CompanyX`.
Queries in `inputs/regeneration-20261016/headers.sql` and `lines.sql` select only
orders strictly before 2013-10-01. Export checksums, normalization checksums,
coverage declaration, and limitations are in that directory's `source_manifest.json`.
No database changes, operational model training, or October final-test label
construction occurred. The checkout remains on main.

Raw exports contain 2,729 headers and 44,576 lines. The existing clean-order
contract accepts 2,723 orders and 44,501 lines, excluding six established rejected
order IDs. Source reconciliation passes. The complete declared interval is
[2011-05-31, 2013-10-01). Source completeness and historical order-time availability
remain assumptions of the restored database, not conclusions inferred from
the first/last observed purchase dates.

## Successful preparation command

```powershell
.venv/Scripts/python.exe -m reseller_churn prepare --orders datasets/orders_clean.csv --stores datasets/stores_clean.csv --headers inputs/regeneration-20261016/order_headers.csv --lines inputs/regeneration-20261016/order_lines.csv --coverage-from 2011-05-31 --coverage-through 2013-10-01 --output results/dataset-regeneration-20261016/verified-preparation
```

The directory already exists; use a fresh output directory for any later run.
The approved CLI produces exactly the same dataset bytes as the earlier direct
call to the unchanged `load_sources` and `build_development` functions retained
under `preparation/`. `verified-preparation/` is the final CLI-produced artifact.

## Checks

- 1,375 unique reseller/snapshot rows, ten feature columns, 212 churn cases.
- Snapshot row/churn counts: July 2012 326/76; October 2012 366/47;
  January 2013 343/25; April 2013 340/64.
- Seven base features and all labels agree with the tracked historical reference
  at research commit 184924421791aec66d6e9e71cd6cbd8367709756 within numerical
  tolerance. Maximum annual-revenue absolute difference is 5.82e-11.
- All 1,375 rows' discount features independently checked using Decimal arithmetic
  directly on accepted source lines. Maximum absolute difference is 1.11e-16.
- Native missing patterns preserved: recent weighted discount 154 missing,
  discount change 433 missing, annual discounted-line share zero missing.
- `python -m pytest -q`: 44 passed, recorded in `pytest.txt`.
- The original expanded training CSV/hash was not recovered. Exact original-file
  identity is therefore not asserted.

## Runtime

Python 3.12.14, pandas 3.0.1, NumPy 2.3.5, scikit-learn 1.9.1, joblib 1.6.0.
Windows application control blocked a DLL in newly installed pandas 3.0.6.
The local venv was configured with standard `--system-site-packages` to reuse
the functioning bundled pandas and NumPy; their newly installed duplicates were
removed only from this workspace's venv. Bundled dependencies and security policy
were not modified. The final isolated subprocess smoke test included in pytest
passes in this environment.

The package source is unchanged. Code, input, and output hashes are recorded in
the preparation manifest. Verification code and independent checks are retained
locally for review. Generated inputs, datasets, and presentations remain ignored.
