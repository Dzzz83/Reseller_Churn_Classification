"""Use the unchanged prepare-stage data functions without importing model DLLs."""
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys
import pandas as pd
import numpy as np

root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root))
from reseller_churn.data import load_sources,build_development
run=Path(__file__).resolve().parent
paths={'orders':root/'datasets/orders_clean.csv','stores':root/'datasets/stores_clean.csv','headers':root/'inputs/regeneration-20261016/order_headers.csv','lines':root/'inputs/regeneration-20261016/order_lines.csv'}
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
sources=load_sources(paths,'2011-05-31','2013-10-01','2013-10-01')
data=build_development(sources)
output=run/'preparation'
output.mkdir(exist_ok=False)
data.to_csv(output/'development.csv',index=False)
manifest={
 'stage':'prepare',
 'execution':'Unchanged reseller_churn.data.load_sources and build_development called directly. CLI could not import installed model/scientific DLLs under Windows application control.',
 'inputs':{k:{'path':str(p.resolve()),'sha256':digest(p)} for k,p in paths.items()},
 'coverage_from':'2011-05-31','coverage_through':'2013-10-01','rows':len(data),
 'snapshots':sorted(data.snapshot.dt.strftime('%Y-%m-%d').unique()),
 'final_outcomes_constructed':False,
 'source_audit':{'accepted_orders':len(sources.orders),'accepted_lines':len(sources.lines),'excluded_raw_order_ids':list(sources.excluded_order_ids),'reconciliation':'passed'},
 'source':{'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'package_sha256':{p.name:digest(p) for p in sorted((root/'reseller_churn').glob('*.py'))},'versions':{'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__}},
 'outputs':{'development.csv':digest(output/'development.csv')},
 'models_trained':0,
 'source_manifest_sha256':digest(root/'inputs/regeneration-20261016/source_manifest.json'),
 'wrapper_sha256':digest(Path(__file__)),
}
(output/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True,allow_nan=False)+'\n',encoding='utf-8')
print(json.dumps({'rows':len(data),'churn_cases':int(data.churn.sum()),'source_audit':manifest['source_audit'],'dataset':str(output/'development.csv')},indent=2))
