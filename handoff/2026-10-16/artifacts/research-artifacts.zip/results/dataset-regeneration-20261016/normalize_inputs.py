import csv
import hashlib
import io
import json
from datetime import datetime, timezone
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parents[2]
inputs = root / 'inputs/regeneration-20261016'
def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()
metadata = {}
for stem, columns, expected in [
    ('headers', ['StoreID','SalesOrderID','OrderDate','SubTotal'], 2729),
    ('lines', ['SalesOrderID','SalesOrderDetailID','ProductID','OrderQty','UnitPrice','UnitPriceDiscount','LineTotal'], 44576),
]:
    raw = inputs / f'{stem}-raw.csv'
    rows = list(csv.reader(io.StringIO(raw.read_text(encoding='utf-8-sig'))))
    rows = [r for r in rows if any(v.strip() for v in r)]
    assert len(rows) == expected, (stem, len(rows))
    assert all(len(r)==len(columns) for r in rows)
    output = inputs / f'order_{stem}.csv'
    with output.open('w',newline='',encoding='utf-8') as stream:
        writer = csv.writer(stream)
        writer.writerow(columns)
        writer.writerows(rows)
    metadata[output.name]={'rows':len(rows),'sha256':digest(output),'raw_sha256':digest(raw),'query_sha256':digest(inputs/f'{stem}.sql')}
manifest = {
    'created_at_utc':datetime.now(timezone.utc).isoformat(),
    'source':{'server':'localhost','database':'CompanyX','access':'SELECT only, Windows integrated authentication','export_cutoff_exclusive':'2013-10-01'},
    'coverage':{'from':'2011-05-31','through_exclusive':'2013-10-01','basis':'Complete historical reseller header and detail SELECTs from the restored CompanyX source, using the frozen documented interval; reconciled against accepted clean-order references by the preparation pipeline.','limitations':['Source completeness and order-time availability remain assumptions of the restored source. Observed minimum/maximum dates are not treated as independent proof of completeness.','No October 2013 or later source orders or final test outcomes were queried.']},
    'exports':metadata,
    'reference_inputs':{str(p.relative_to(root)):digest(p) for p in [root/'datasets/orders_clean.csv',root/'datasets/stores_clean.csv']},
    'code_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    'original_expanded_training_artifact_available':False,
    'models_trained':0,
}
(inputs/'source_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps(metadata,indent=2))
