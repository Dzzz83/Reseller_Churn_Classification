import csv
from collections import defaultdict
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import sys
import subprocess

root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root))
import numpy as np
import pandas as pd
from reseller_churn.config import FEATURES, DISCOUNT_FEATURES
def verify_manifest(directory):
    value=json.loads((directory/'manifest.json').read_text(encoding='utf-8'))
    for name,expected_hash in value['outputs'].items():
        assert hashlib.sha256((directory/name).read_bytes()).hexdigest()==expected_hash
    return value
def source_identity():
    return json.loads((Path(__file__).resolve().parent/'verified-preparation/manifest.json').read_text(encoding='utf-8'))['source']
def validate_features(frame):
    assert np.isfinite(frame[list(FEATURES[:7])].to_numpy(dtype=float)).all()
    assert not np.isinf(frame[list(DISCOUNT_FEATURES)].to_numpy(dtype=float)).any()

run=Path(__file__).resolve().parent
prep=run/'verified-preparation'
manifest=verify_manifest(prep)
data=pd.read_csv(prep/'development.csv',parse_dates=['snapshot'],float_precision='round_trip')
validate_features(data)
assert list(data.columns)==['StoreID','snapshot',*FEATURES,'churn']
assert len(data)==1375 and int(data.churn.sum())==212
assert not data.duplicated(['StoreID','snapshot']).any()
expected={'2012-07-01':(326,76),'2012-10-01':(366,47),'2013-01-01':(343,25),'2013-04-01':(340,64)}
counts={str(s.date()):(len(g),int(g.churn.sum())) for s,g in data.groupby('snapshot')}
assert counts==expected, counts
reference_commit='184924421791aec66d6e9e71cd6cbd8367709756'
reference_bytes=subprocess.check_output(['git','show',f'{reference_commit}:datasets/processed/ml_labeled_snapshots.csv'],cwd=root)
reference_path=run/'reference_labeled_snapshots.csv'
reference_path.write_bytes(reference_bytes)
reference=pd.read_csv(reference_path,parse_dates=['snapshot'])
joined=data.merge(reference,on=['StoreID','snapshot'],suffixes=('_new','_reference'),validate='one_to_one',how='outer',indicator=True)
assert joined['_merge'].eq('both').all()
base_differences={}
for col in FEATURES[:7]:
    actual=joined[f'{col}_new'].to_numpy()
    wanted=joined[f'{col}_reference'].to_numpy()
    np.testing.assert_allclose(actual,wanted,atol=1e-10,rtol=1e-10)
    base_differences[col]=float(np.max(np.abs(actual-wanted)))
np.testing.assert_array_equal(joined.churn_new,joined.churn_reference)

# Independent decimal calculation from accepted source lines, without calling
# the pipeline's discount helper or filling missing observations.
inputs=root/'inputs/regeneration-20261016'
clean=pd.read_csv(root/'datasets/orders_clean.csv',usecols=['SalesOrderID','OrderDate'],parse_dates=['OrderDate'])
accepted=set(clean.loc[clean.OrderDate.lt('2013-10-01'),'SalesOrderID'].astype(int))
with (inputs/'order_headers.csv').open(newline='',encoding='utf-8') as stream:
    header={int(r['SalesOrderID']):(int(r['StoreID']),pd.Timestamp(r['OrderDate'])) for r in csv.DictReader(stream) if int(r['SalesOrderID']) in accepted}
store_lines=defaultdict(list)
with (inputs/'order_lines.csv').open(newline='',encoding='utf-8') as stream:
    for r in csv.DictReader(stream):
        key=int(r['SalesOrderID'])
        if key not in header: continue
        store,date=header[key]
        gross=Decimal(r['OrderQty'])*Decimal(r['UnitPrice'])
        discount=Decimal(r['UnitPriceDiscount'])
        store_lines[store].append((date,gross,discount))
max_errors={name:0.0 for name in DISCOUNT_FEATURES}
for row in data.itertuples(index=False):
    snapshot=row.snapshot
    recent_start=snapshot-pd.DateOffset(months=3)
    previous_start=snapshot-pd.DateOffset(months=6)
    year_start=snapshot-pd.DateOffset(months=12)
    recent=[]; previous=[]; year=[]
    for dt,gross,discount in store_lines[int(row.StoreID)]:
        if year_start<=dt<snapshot:
            year.append((gross,discount))
            if dt>=recent_start: recent.append((gross,discount))
            elif dt>=previous_start: previous.append((gross,discount))
    def weighted(lines):
        if not lines: return None
        return sum((g*d for g,d in lines),Decimal(0))/sum((g for g,d in lines),Decimal(0))
    recent_value=weighted(recent); previous_value=weighted(previous)
    wanted={
        'weighted_discount_3m':recent_value,
        'discount_change_3m':None if recent_value is None or previous_value is None else recent_value-previous_value,
        'discounted_line_share_12m':None if not year else Decimal(sum(d>0 for g,d in year))/Decimal(len(year)),
    }
    for name,value in wanted.items():
        actual=float(getattr(row,name))
        if value is None: assert np.isnan(actual),(row.StoreID,str(snapshot),name)
        else:
            error=abs(actual-float(value))
            assert error<1e-12,(row.StoreID,str(snapshot),name,error)
            max_errors[name]=max(max_errors[name],error)

# Use an active churn example with observed discounts when possible.
candidates=data.loc[data.churn.eq(1)&data.n_orders_3m.gt(0)&data[list(DISCOUNT_FEATURES)].notna().all(axis=1)&data.weighted_discount_3m.gt(0)&data.discount_change_3m.ne(0)]
assert not candidates.empty
example=candidates.sort_values(['snapshot','StoreID']).iloc[[0]]
example.to_csv(run/'actual_training_row.csv',index=False,date_format='%Y-%m-%d')
summary={
 'status':'passed','rows':len(data),'features':list(FEATURES),'churn_cases':int(data.churn.sum()),
 'snapshots':{k:{'rows':v[0],'churners':v[1]} for k,v in counts.items()},
 'reference':{'branch':'pipeline_preparation','commit':reference_commit,'sha256':hashlib.sha256(reference_bytes).hexdigest(),'base_feature_max_absolute_differences':base_differences,'labels_identical':True},
 'independent_decimal_discount_check':{'rows_checked':len(data),'maximum_absolute_errors':max_errors,'missing_patterns_verified':True},
 'missing_discount_counts':{k:int(data[k].isna().sum()) for k in DISCOUNT_FEATURES},
 'development_csv_sha256':hashlib.sha256((prep/'development.csv').read_bytes()).hexdigest(),
 'source_manifest_sha256':hashlib.sha256((inputs/'source_manifest.json').read_bytes()).hexdigest(),
 'verification_code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'code_and_runtime':source_identity(),
 'original_expanded_artifact_exact_parity':'Not established: original generated ten-feature CSV/hash unavailable. Base references and independent discount calculations pass.',
 'models_trained':0,'october_test_outcomes_accessed':False,
 'example':json.loads(example.to_json(orient='records',date_format='iso'))[0],
}
(run/'verification.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n',encoding='utf-8')
print(json.dumps(summary,indent=2))


