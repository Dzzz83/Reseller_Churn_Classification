# Repeated nested grouped precision study

The predeclared evidence criteria do not support a reliable replacement. No final candidate was frozen and no test evaluation was run. Exploratory configurations below must not be promoted using these same outer scores as an independent performance estimate.

## Protocol

The target is maximum precision while recall stays strictly above 90%.
This run uses 320 approved development account/snapshot rows,
80 resellers, and 93 churn cases.
Only July/October 2012 and January/April 2013 are allowed. Final testing data
is not an input, no test features or outcomes are opened, and no temporal
validation is performed. Earlier inspection of this development dataset makes
the study exploratory rather than a new independent final evaluation.

Three predefined split seeds (42, 78, 88) each make five outer grouped folds.
Three inner grouped folds, seed 78, use only the outer-training population.
All snapshots of one reseller stay in the same fold at both levels. All
candidates share identical splits and populations. Class weights use the
current fit's training labels only. Missing discounts and undefined ratios
remain native missing values. No preprocessing is learned on outer rows.

Eight configurations cross four feature sets (original ten; plus spending
ratios; plus cadence; plus all six additions) with two settings (original
boosting parameters; or seven leaves and L2=1). Five model seeds and all other
model parameters are preserved. Inner OOF predictions select the cutoff that
maximizes precision subject to pooled inner recall >90%; ties favor recall
then higher cutoff. Configuration ties favor recall, fewer features, then
stable configuration ID. The complete grid, inputs, code hash, split seeds,
and decision rules were saved to `protocol.json` before any fitting.

The primary comparison is **adaptive_selection** (configuration and cutoff
chosen inside training) against **original_baseline** (original ten-feature
model, cutoff chosen by the same inner rule). **full_baseline** is the earlier
six-feature addition with original parameters. **original_fixed_006** is a
reference only. Each outer fold freezes its own configuration/cutoff before
scoring; pooled results do not describe one deployment cutoff.

## Held-out grouped validation results

| Repeat | Procedure | Recall | Precision | Caught | Missed | False alerts |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| 42 | adaptive_selection | 82.80% | 27.60% | 77 | 16 | 202 |
| 42 | original_baseline | 87.10% | 27.65% | 81 | 12 | 212 |

Primary mean precision gain: **-0.05 percentage points**.
Paired reseller-cluster 95% percentile interval: **-1.62 to +1.80 points**.
All repetitions above 90% recall: **False**.
Predeclared eligibility: **False**.
Strong-support rule (eligible plus positive lower precision bound): **False**.

The 5,000 bootstrap draws resample whole resellers, carrying every snapshot
and repeat prediction together. This interval conditions on the already
fitted models and selected cutoffs; it does not include retraining/reselection
uncertainty. Repetitions overlap and are dependent. It is a marginal interval
for the single predeclared precision comparison, not simultaneous evidence
for every exploratory configuration.

## Exploratory configuration summaries

| Configuration | Mean repeat recall | Mean repeat precision | Repeats above 90% recall |
| --- | ---: | ---: | ---: |
| adaptive_selection | 82.80% | 27.60% | 0/1 |
| full_regularized | 91.40% | 28.43% | 1/1 |
| original_baseline | 87.10% | 27.65% | 0/1 |
| original_fixed_006 | 81.72% | 26.95% | 0/1 |

These summaries are diagnostic. Selecting a fixed winner after inspecting
their outer scores introduces additional development selection. The primary
adaptive procedure already evaluates model selection inside training folds.
Do not sum the three repetitions as independent accounts or compute a larger
sample size from repeated predictions.

Adaptive configuration frequencies across outer folds: `{"full_regularized": 1, "original_baseline": 1}`.
Paired gained/lost churners and removed/added false alerts are in
`paired_changes.csv`; fold-specific outcomes and subgroup metrics are in
`fold_metrics.csv` and `repeat_metrics.csv`.

| Procedure | Subgroup | Mean repeat recall | Mean repeat precision |
| --- | --- | ---: | ---: |
| adaptive_selection | active | 82.61% | 26.64% |
| adaptive_selection | inactive | 83.33% | 30.77% |
| original_baseline | active | 89.86% | 27.43% |
| original_baseline | inactive | 79.17% | 28.36% |

## Final state and limitations

Research candidate frozen: **False**.
Final testing evaluated: **False**. Operational model changed: **False**.
Main branch changed: **False**. No push or merge is performed.

The study answers generalization to held-out reseller identities. Source
availability, source completeness, small development population, repeated
snapshot dependence, and prior exploratory inspection remain limitations.
Outer recall below the target is a failure of the operating objective even
when inner recall exceeded 90%. A training constraint is not an outer
validation guarantee. No new independent final performance is claimed.

## Verification

Independent saved-output checks verified all file hashes, every population
join, outer and inner reseller separation, inner cutoff optimization and
configuration selection, adaptive-to-selected prediction identity, and
36 metric rows. All 60
outer-study estimator fits completed. Maximum observed seed score range is
0.0; identical seed predictions
are not independent robustness confirmations.

Eight focused synthetic tests and a standalone synthetic end-to-end smoke
passed before this study. The normal repository-wide pytest command remains
blocked by pre-existing duplicate TOML tables; existing package conflict
markers were not changed. Synthetic smoke results are execution evidence,
not model-quality evidence.

Input/code/runtime specifications, fold assignments, inner and outer saved
predictions, model hashes and training-content identities are retained in
this ignored run directory. Verification is reproducible using:

```powershell
.venv/Scripts/python.exe comparisons/verify_grouped_precision_recall.py results/grouped-precision-smoke
```
