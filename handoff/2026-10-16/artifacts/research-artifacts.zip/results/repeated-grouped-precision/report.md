# Repeated nested grouped precision study

The predeclared adaptive selection procedure meets the repeat-level recall target and has a positive paired bootstrap precision interval. A research candidate was frozen using development only; it is not an independently tested or deployed replacement.

## Protocol

The target is maximum precision while recall stays strictly above 90%.
This run uses 1375 approved development account/snapshot rows,
422 resellers, and 212 churn cases.
Only July/October 2012 and January/April 2013 are allowed. Final testing data
is not an input, no test features or outcomes are opened, and no temporal
validation is performed. Earlier inspection of this development dataset makes
the study exploratory rather than a new independent final evaluation.

The predefined split seeds [42, 78, 88] each make
5 outer grouped folds. Within each outer training set,
3 inner grouped folds use seed 78.
All snapshots of one reseller stay in the same fold at both levels. All
candidates share identical splits and populations. Class weights use the
current fit's training labels only. Missing discounts and undefined ratios
remain native missing values. No preprocessing is learned on outer rows.

Eight configurations cross four feature sets (original ten; plus spending
ratios; plus cadence; plus all six additions) with two settings (original
boosting parameters; or seven leaves and L2=1). Five model seeds and all other
model parameters are preserved. Inner OOF predictions select the cutoff that
maximizes precision subject to pooled inner recall >90%; ties favor recall
then higher cutoff. Configuration ties favor recall, fewer features, then
stable configuration ID. The complete grid, inputs, code hash, split seeds,
and decision rules were saved to `protocol.json` before any fitting.

The primary comparison is **adaptive_selection** (configuration and cutoff
chosen inside training) against **original_baseline** (original ten-feature
model, cutoff chosen by the same inner rule). **full_baseline** is the earlier
six-feature addition with original parameters. **original_fixed_006** is a
reference only. Each outer fold freezes its own configuration/cutoff before
scoring; pooled results do not describe one deployment cutoff.

## Held-out grouped validation results

| Repeat | Procedure | Recall | Precision | Caught | Missed | False alerts |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| 42 | adaptive_selection | 91.51% | 29.48% | 194 | 18 | 464 |
| 42 | full_baseline | 92.92% | 28.55% | 197 | 15 | 493 |
| 42 | original_baseline | 91.98% | 26.90% | 195 | 17 | 530 |
| 78 | adaptive_selection | 92.92% | 29.62% | 197 | 15 | 468 |
| 78 | full_baseline | 91.51% | 29.31% | 194 | 18 | 468 |
| 78 | original_baseline | 90.57% | 27.87% | 192 | 20 | 497 |
| 88 | adaptive_selection | 90.09% | 30.13% | 191 | 21 | 443 |
| 88 | full_baseline | 87.74% | 28.79% | 186 | 26 | 460 |
| 88 | original_baseline | 91.98% | 26.71% | 195 | 17 | 535 |

Primary mean precision gain: **+2.59 percentage points**.
Paired reseller-cluster 95% percentile interval: **+1.67 to +3.52 points**.
All repetitions above 90% recall: **True**.
Predeclared eligibility: **True**.
Strong-support rule (eligible plus positive lower precision bound): **True**.

The 5,000 bootstrap draws resample whole resellers, carrying every snapshot
and repeat prediction together. This interval conditions on the already
fitted models and selected cutoffs; it does not include retraining/reselection
uncertainty. Repetitions overlap and are dependent. It is a marginal interval
for the single predeclared precision comparison, not simultaneous evidence
for every exploratory configuration.

## Exploratory configuration summaries

| Configuration | Mean repeat recall | Mean repeat precision | Repeats above 90% recall |
| --- | ---: | ---: | ---: |
| adaptive_selection | 91.51% | 29.74% | 3/3 |
| cadence_baseline | 91.04% | 29.25% | 2/3 |
| cadence_regularized | 94.65% | 29.31% | 3/3 |
| full_baseline | 90.72% | 28.88% | 2/3 |
| full_regularized | 94.18% | 28.65% | 3/3 |
| original_baseline | 91.51% | 27.16% | 3/3 |
| original_fixed_006 | 77.36% | 32.96% | 0/3 |
| original_regularized | 94.03% | 27.06% | 3/3 |
| spending_baseline | 91.19% | 27.72% | 3/3 |
| spending_regularized | 94.34% | 27.55% | 3/3 |

These summaries are diagnostic. Selecting a fixed winner after inspecting
their outer scores introduces additional development selection. The primary
adaptive procedure already evaluates model selection inside training folds.
Do not sum the three repetitions as independent accounts or compute a larger
sample size from repeated predictions.

Adaptive configuration frequencies across outer folds: `{"cadence_baseline": 2, "cadence_regularized": 5, "full_baseline": 2, "full_regularized": 3, "spending_baseline": 1, "spending_regularized": 2}`.
Paired gained/lost churners and removed/added false alerts are in
`paired_changes.csv`; fold-specific outcomes and subgroup metrics are in
`fold_metrics.csv` and `repeat_metrics.csv`.

| Procedure | Subgroup | Mean repeat recall | Mean repeat precision |
| --- | --- | ---: | ---: |
| adaptive_selection | active | 85.95% | 20.76% |
| adaptive_selection | inactive | 98.90% | 59.48% |
| original_baseline | active | 85.12% | 18.38% |
| original_baseline | inactive | 100.00% | 59.09% |

## Final state and limitations

Research candidate frozen: **True**.
Final testing evaluated: **False**. Operational model changed: **False**.
Main branch changed: **False**. No push or merge is performed.

Full-development inner selection chose `cadence_regularized` with features `n_orders_3m, revenue_3m, recency_days, share_bikes, share_accessories, share_clothing, revenue_12m, weighted_discount_3m, discount_change_3m, discounted_line_share_12m, overdue_ratio, n_orders_12m, gap_cv` and cutoff `0.21655335464238584`. This full-data refit was selected by the evaluated procedure; the table is not a separate validation of this single fixed model.

The >90% recall rule is pooled per repetition. Only
11/15 individual outer
folds exceed it; minimum fold recall is 71.43%.
The weakest repeat has 90.09% recall. This must not be presented
as an every-fold or future guarantee.

The study answers generalization to held-out reseller identities. Source
availability, source completeness, small development population, repeated
snapshot dependence, and prior exploratory inspection remain limitations.
Outer recall below the target is a failure of the operating objective even
when inner recall exceeded 90%. A training constraint is not an outer
validation guarantee. No new independent final performance is claimed.

## Verification

Independent saved-output checks verified all file hashes, every population
join, outer and inner reseller separation, inner cutoff optimization and
configuration selection, adaptive-to-selected prediction identity, and
540 metric rows. All 2400
outer-study estimator fits completed. Final full-development selection/refitting
adds 125 study fits;
5 additional deterministic refits check
saved-bundle fidelity without estimating quality. Maximum observed seed score range is
0.0; identical seed predictions
are not independent robustness confirmations.

Eight focused synthetic tests and a standalone synthetic end-to-end smoke
passed before this study; all 14 study/diagnosis tests passed afterward.
During execution, the user requested repair of the duplicate TOML sections.
Those sections and the package initializer's committed conflict markers were
fixed on the research branch. Full pytest now gets further but is blocked by
a separate module/package collision: the research `reseller_churn.config`
package shadows the merged final pipeline's `config.py`, so its CLI cannot
import `TRAINING_SNAPSHOTS`. The standalone study does not import that package.
Synthetic smoke results are execution evidence, not model-quality evidence.

Input/code/runtime specifications, fold assignments, inner and outer saved
predictions, model hashes and training-content identities are retained in
this ignored run directory. Verification is reproducible using:

```powershell
.venv/Scripts/python.exe comparisons/verify_grouped_precision_recall.py results/repeated-grouped-precision
```
