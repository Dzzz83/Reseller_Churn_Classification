# Frozen candidate evaluation on the inspected October cohort

The frozen candidate **fails the requested precision-improvement objective**
on this cohort: recall is 97.83%, but precision is 20.09%
versus 28.48% for the original rule. It catches
2 additional churners with 71 net additional
false alerts. No cutoff or parameter was changed after evaluation.

## Frozen method and cohort

User explicitly requested: "evaluate using the final test set." The evaluated
candidate was saved before this request: original ten features plus overdue
ratio, annual order count, and purchase-gap variation, seven leaves, L2=1,
five registered model seeds averaged, native missing handling, training-only
balanced weights, and development-selected cutoff `0.21655335464238584`.
The original comparison uses its preserved 0.06 rule. No alternative feature
set or cutoff was evaluated to choose a test winner.

Scoring date is 2013-10-01; outcomes cover [2013-10-01,2014-04-01).
There are 492 accounts and 46 churners. October outcomes were already
inspected before this follow-up. This is **descriptive reuse**, not a new
independent test. It does not retroactively change the original test record.

The supplied unlabeled scoring CSV and supplied outcome CSV have separate
checksums from the earlier reconstruction. Prediction loads the existing
frozen bundle, verifies parameters/runtime/input identities, and writes a
checkpoint. A separate explicitly approved evaluation stage verifies that
checkpoint before reading supplied labels. Neither stage fits a model,
optimizes cutoffs, queries a database, or constructs outcomes.

## Results

| Model / frozen cutoff | Recall | Precision | Caught | Missed | False alerts | Alerts | AP |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| frozen_cadence_candidate / 0.2165533546 | 97.83% | 20.09% | 45 | 1 | 179 | 224 | 0.7892 |
| original_baseline / 0.0600000000 | 93.48% | 28.48% | 43 | 3 | 108 | 151 | 0.7013 |

Precision difference: -8.39 percentage points.
Recall difference: +4.35 points.
Paired decisions: 2 newly caught churners,
0 newly missed, 10 false
alerts removed, and 81 added.

| Model | Subgroup | Recall | Precision | Caught | False alerts |
| --- | --- | ---: | ---: | ---: | ---: |
| frozen_cadence_candidate | active | 90.91% | 5.59% | 10 | 169 |
| frozen_cadence_candidate | inactive | 100.00% | 77.78% | 35 | 10 |
| original_baseline | active | 72.73% | 7.55% | 8 | 98 |
| original_baseline | inactive | 100.00% | 77.78% | 35 | 10 |

The net false-alert increase occurs among active accounts. Overall ranking AP
improves, but active-subgroup AP falls from 0.1553 to 0.0765; inactive-subgroup
AP improves from 0.8870 to 0.9469. The aggregate ranking improvement therefore
does not establish better active-account discrimination or a better frozen
operating point. Scores are not validated calibrated individual risks.

Grouped development gains did not transfer into improved October precision
at the frozen cutoff. Do not promote this candidate as meeting the user's
objective on this cohort. Retain the result and, if further development is
authorized, choose changes using development data rather than optimizing this
inspected test result.

## Provenance and verification

All model, feature, prediction-checkpoint, and supplied-outcome hashes are
recorded. Independent checks reproduce every score from the saved model,
all six metric rows, alert equality at the frozen cutoff, and the original
baseline confusion counts. Source model and cutoff remain unchanged.

Original baseline scores are a documented local reproduction; exact original
artifact identity is unavailable. Counts match the recorded 43 caught, three
missed, and 108 false alerts. Outcomes reuse the earlier accepted-orders CSV
reconstruction; no fresh source-database reconciliation is performed here.
These source limitations and prior cohort inspection remain material.

The seven new synthetic tests cover unlabeled scoring, scope/population/hash
guards, explicit approval, checkpoint integrity, and a no-fit two-stage smoke.
Synthetic smoke checks execution only. The broader repository suite remains
blocked by the previously documented config module/package collision.

No training, test-driven retuning, operational-model replacement, push, or
merge was performed.
